# Instalacion de dependencias
```
npm install
```
## Iniciar el proyecto
```
npm run dev
```