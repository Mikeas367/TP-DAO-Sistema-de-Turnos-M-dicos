
export interface EstadoTurno {
  id: number;
  nombre: string;
  descripcion: string;
}
